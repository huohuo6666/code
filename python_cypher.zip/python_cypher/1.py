my_variable = "123456789"
