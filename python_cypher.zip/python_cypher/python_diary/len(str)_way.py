


def findLen(str):

counter = 0

while str[counter: :]

counter += 1

return counter
jjhjjjjjj
str = "while 循环"

print(findLen(str))