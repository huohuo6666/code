#   求一个数的所有本原根


# 求最大公因子

def gcd(a,b):
    r=a%b
    while(r!=0):
        a=b
        b=r
        r=a%b
    return b

# 欧拉函数

def oula(a):
    count=0
    for i in range(1,a):
        if gcd(a,i)==1:
            count+=1
    return count


def order(b,o,n):               #o是n的欧拉函数值，n是要求所有本原根的数
    p=1
    while (p<=o and (b**p%n!=1)):
          p+=1
    if p<=n and p==o:           #保证只有在p=o时才b**pmodn=1
          return p
    else:
          return -1

# 求任意数原根
def benyuangen(n):
    o=oula(n)
    print(f'100的欧拉函数值为{o}')
    benyuangen=[]
    for b in range(2,n):
        if gcd(b,n) ==1:  
            if order(b,o,n)==o:
                benyuangen.append(b)
    print(f"{n}所有本原根:",benyuangen)
    
    
if __name__ == "__main__":
    n=int(input("请输入一个数字:"))
    benyuangen(n)
    
    
    
    